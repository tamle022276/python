# Student.py - Student class
from Person import Person

class Student(Person):
    # your code here...

