# Person.py - Person class

class Person:
    # your code here...
