#!/usr/bin/env python
# sets.py - intersect and union functions

def intersect(*args):
    # your code here...

def union(*args):
    # your code here...

print intersect([1, 2, 3, 4], (2, 4, 6, 8), [2, 4])
print union([1, 2, 3, 4], (2, 4, 6, 8), [3, 9])

#####################################
#
#     $ sets.py
#     [2, 4]
#     [1, 2, 3, 4, 6, 8, 9]
#
