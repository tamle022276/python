#!/usr/bin/env python
# mytuple.py - lists and tuples

mytuple = (45,23,101,[66,12,33],17,29)

# your code here...

print mytuple

##########################################

#    $ mytuple.py
#    (12, 17, 23, 29, 33, 45, 66, 101)
