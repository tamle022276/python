# BArray.py - Bounded Array

class BArray:
    # your code here...

