#!/usr/bin/env python
# converter.py - Fahrenheit and Celsius converter
import sys

arg = sys.argv[1]

# your code here...

##########################################

#    $ converter.py 23c
#    73.4f
#
#    $ converter.py 73.4f
#    23c
