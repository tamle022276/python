"""myinterest.__main__: executes when myinterest directory called as script."""

from .myinterest import main
main()
