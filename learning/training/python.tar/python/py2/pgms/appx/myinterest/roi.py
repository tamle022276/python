#!/usr/bin/env python
# roi.py - return on investment
from myinterest.myinterest import calc

calc(65000, 5.5, 5)

###############################################
#
#    $ roi.py
#    1 (+3575) => 68575.00
#    2 (+3771) => 72346.62
#    3 (+3979) => 76325.69
#    4 (+4197) => 80523.60
#    5 (+4428) => 84952.40
#
