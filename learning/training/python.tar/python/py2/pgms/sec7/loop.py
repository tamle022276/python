#!/usr/bin/env python
# loop.py - print elements in loop

for i in range(3):
    for j in range(3):
        print i, j

##################################################
#
#     $ loop.py
#     0 0
#     0 1
#     0 2
#     1 0
#     1 1
#     1 2
#     2 0
#     2 1
#     2 2
#
