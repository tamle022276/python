#!/usr/bin/env python
# mod3.py - module 3

def f():
    print "module 3"
