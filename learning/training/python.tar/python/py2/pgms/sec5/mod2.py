#!/usr/bin/env python
# mod2.py - module 2
import mod3

def f():
    print "module 2"

f()
mod3.f()

#####################################
#
#     $ mod2.py
#     module 2
#     module 3
#
