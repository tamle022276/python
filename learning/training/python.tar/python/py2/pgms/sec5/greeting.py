# greeting.py

def f():
    print "first time"
