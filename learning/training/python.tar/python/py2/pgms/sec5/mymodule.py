# mymodule.py - my module

var = 1
mylist = [1, 2]
