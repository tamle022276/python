def multdup(a, b):
    """
    >>> multdup(5, 2)
    10
    >>> multdup("No", 4)
    'NoNoNoNo'
    >>>
    """
    return a * b
