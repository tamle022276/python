#!/usr/bin/env python
# pstrings.py - print strings

print "one",         # no newline, add space
print "two",         # no newline, add space
print "three"        # add newline

###############################################
#
#    $ pstrings.py
#    one two three
#
