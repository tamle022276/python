#!/usr/bin/env python
# myrecord.py - Records

rec = {}
rec["name"] = "Bob Smith"
rec["age"] = 42
rec["weight"] = 185.5

print "%s's age is %d" %(rec["name"], rec["age"])

#################################################
#
#    $ myrecord.py
#    Bob Smith's age is 42
#
