#!/usr/bin/env python3
# prices.py - min(), max() for dictionary

prices = {"ACME" : 45.23, "AAPL" : 94.43, "IBM" : 192.05,
          "HPQ" : 34.81, "FB" : 68.42}

# your code here...

##########################################

#    $ prices.py
#    (34.81, 'HPQ')
#    (192.05, 'IBM')
