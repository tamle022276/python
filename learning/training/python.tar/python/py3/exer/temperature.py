#!/usr/bin/env python3
# temperature.py - Fahrenheit and Celsius converter
import sys

# your code here...

###################################################

#    $ temperature.py 40
#    celsius to farenheit = 104 
#    farenheit to celsius = 4.44444

#    $ temperature.py -40
#    celsius to farenheit = -40 
#    farenheit to celsius = -40
#
