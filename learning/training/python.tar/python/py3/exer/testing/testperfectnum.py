#!/usr/bin/env python3
# testperfectnum.py - test perfect numbers
import unittest
from PerfectNumber import isPerfect

class TestPerfectNumber(unittest.TestCase):
    def testEqual(self):
        # your code here...

if __name__ == "__main__":
   unittest.main()
