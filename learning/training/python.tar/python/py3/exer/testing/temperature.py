#!/usr/bin/env python3
# temperature.py - Fahrenheit and Celsius converter

# your code here...
