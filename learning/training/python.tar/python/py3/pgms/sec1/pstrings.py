#!/usr/bin/env python3
# pstrings.py - print strings

print("one", end =" ")         # no newline, add space
print("two", end = " ")        # no newline, add space
print("three")                 # add newline

###############################################
#
#    $ pstrings.py
#    one two three
#
