#!/usr/bin/env python3
# multdup.py - multiply or dup function

def multdup(a, b):
    return a * b

print(multdup(5, 2))
print(multdup("No", 4))

#####################################
#
#     $ multdup.py
#     10 
#     NoNoNoNo
#
