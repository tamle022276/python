#!/usr/bin/env python3
# testrunner.py - test runner
"""Convenience wrapper for running myinterest directly from source tree."""

from myinterest.myinterest import main

if __name__ == '__main__':
    main()
