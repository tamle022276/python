#!/usr/bin/env python3
# myclass.py - Classes

class rec: pass

person = rec()
person.name = "Bob Smith"
person.age = 42
person.weight = 185.5
print("%s's age is %d" %(person.name, person.age))

#################################################
#
#    $ myclass.py
#    Bob Smith's age is 42
#
