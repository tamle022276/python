#!/usr/bin/env python3
# mod3.py - module 3

def f():
    print("module 3")
